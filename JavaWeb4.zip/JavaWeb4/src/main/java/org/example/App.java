package org.example;

import java.util.Scanner;

public class App {
    public static class Triangle {
        static int perimeter(int a, int b, int c) {
            return a + b + c;
        }

        public static void main(String[] args) {
            Scanner scan = new Scanner(System.in);
            System.out.println("Please enter three length of the triangle's sides");
            System.out.print("a= ");
            int a = scan.nextInt();
            System.out.print("b= ");
            int b = scan.nextInt();
            System.out.print("c= ");
            int c = scan.nextInt();
            if (a + b < c || a + c < b || b + c < a) {
                System.out.println("Эти стороны не образуют треугольника");
                System.exit(0);
            }
            System.out.println("Perimeter:" + perimeter(a, b, c));
            double p1 = perimeter(a, b, c) / 2.0;
            System.out.println("Area:" + Math.sqrt(p1 * (p1 - a) * (p1 - b) * (p1 - c)));
        }
    }
}